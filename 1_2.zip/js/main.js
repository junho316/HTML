// window.onload = function(){
// 	document.querySelector('#mainCarousel .active img').style.transform = "scale(1,1)";
	
// }

